module GoogleDistanceMatrix
  VERSION = "0.0.2"
end
